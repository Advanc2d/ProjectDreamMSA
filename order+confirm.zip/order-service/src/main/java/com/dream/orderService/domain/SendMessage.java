package com.dream.orderService.domain;

import lombok.Data;

@Data
public class SendMessage {
	private String userId;
}
