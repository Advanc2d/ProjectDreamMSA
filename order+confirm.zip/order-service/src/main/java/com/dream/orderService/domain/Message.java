package com.dream.orderService.domain;

import lombok.Data;

@Data
public class Message {
	private String proNo;
}
