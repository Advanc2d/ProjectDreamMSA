package com.dream.confirm.dto;

import lombok.Data;

@Data
public class SendMessage {
	private String userId;
}
