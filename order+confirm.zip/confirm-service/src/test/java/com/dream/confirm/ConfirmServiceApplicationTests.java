package com.dream.confirm;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConfirmServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
